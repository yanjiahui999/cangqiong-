import { sql } from "drizzle-orm";
import { pgTable, serial, varchar, timestamp, jsonb, index } from "drizzle-orm/pg-core";

// Keep health_check table
export const healthCheck = pgTable("health_check", {
  id: serial().notNull(),
  updated_at: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

// Users table for authentication
export const users = pgTable(
  "users",
  {
    username: varchar("username", { length: 50 }).primaryKey(),
    password: varchar("password", { length: 255 }).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("users_created_at_idx").on(table.created_at),
  ]
);

// Team registrations table
export const registrations = pgTable(
  "registrations",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    team_name: varchar("team_name", { length: 100 }).notNull().unique(),
    guild: varchar("guild", { length: 100 }).notNull(),
    captain: varchar("captain", { length: 50 }).notNull(),
    members: jsonb("members").notNull(),
    operator: varchar("operator", { length: 50 }).notNull().references(() => users.username),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("registrations_team_name_idx").on(table.team_name),
    index("registrations_operator_idx").on(table.operator),
    index("registrations_created_at_idx").on(table.created_at),
  ]
);

// Operation logs table
export const operationLogs = pgTable(
  "operation_logs",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    action: varchar("action", { length: 20 }).notNull(), // 'register' or 'cancel'
    team_name: varchar("team_name", { length: 100 }).notNull(),
    operator: varchar("operator", { length: 50 }).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("operation_logs_operator_idx").on(table.operator),
    index("operation_logs_created_at_idx").on(table.created_at),
  ]
);
